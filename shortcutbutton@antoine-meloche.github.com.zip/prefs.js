const { GObject, Gtk, Adw, Gio, GdkPixbuf, GLib } = imports.gi;
const ExtensionUtils = imports.misc.extensionUtils;

function init() {}

function buildPrefsWidget() {
  return new UserCommandPrefsWidget();
}

class UserCommandPrefsWidget extends Adw.PreferencesGroup {
  static {
    GObject.registerClass(this);
  }

  constructor() {
    super({ title: "Shortcut Button Command" });

    let settings = ExtensionUtils.getSettings(
      "org.gnome.shell.extensions.shortcutbutton"
    );

    let commands = settings.get_value("commands").get_strv();
    let icons = settings.get_value("icons").get_strv();

    // Add all commands in the settings
    for (let i = 0; i < commands.length; i++) {
      let command = commands[i];
      let icon = icons[i];

      let commandLabel = new Gtk.Label({
        label: "Command to execute: ",
      });
      let commandEntry = new Gtk.Entry();

      let hBoxCommand = new Gtk.Box();
      hBoxCommand.set_orientation(Gtk.Orientation.HORIZONTAL);
      hBoxCommand.append(commandLabel);
      hBoxCommand.append(commandEntry);

      commandEntry.set_text(command);
      commandEntry.connect("changed", () => {
        commands[i] = commandEntry.get_text();
        settings.set_value("commands", new GLib.Variant("as", commands));
      });

      //

      let iconLabel = new Gtk.Label({
        label: "Icon: ",
      });
      let iconPreview = new Gtk.Image();
      iconPreview.set_from_icon_name(icon, Gtk.IconSize.DIALOG);

      let iconGrid = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL });
      let icons = [];
      let selectedIcon = null;

      // Create Gtk.Image objects for each icon
      let iconPaths = [
        "/usr/share/icons/Adwaita/24x24/actions/system-run.png",
        "/usr/share/icons/Adwaita/24x24/actions/accessories-text-editor.png",
        "/usr/share/icons/Adwaita/24x24/apps/internet-web-browser.png",
        "/usr/share/icons/Adwaita/24x24/emblems/emblem-system.png",
        "/usr/share/icons/Adwaita/24x24/actions/system-lock-screen.png",
        "/usr/share/icons/Adwaita/24x24/actions/system-log-out.png",
      ];
      for (let i = 0; i < iconPaths.length; i++) {
        let icon = new Gtk.Image();
        icon.set_from_file(iconPaths[i]);
        icon.connect("button-press-event", () => {
          if (selectedIcon) {
            selectedIcon.remove_style_class_name("selected");
          }
          if (selectedIcon != icon) {
            icon.add_style_class_name("selected");
            selectedIcon = icon;
          } else {
            selectedIcon = null;
          }
        });
        let iconBox = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL });
        iconBox.add(icon);
        icons.push(icon);
        iconGrid.add(iconBox);
      }

      let dropdownMenu = new Gtk.Box({ orientation: Gtk.Orientation.VERTICAL });
      dropdownMenu.hide();

      dropdownMenu.add(iconGrid);

      let dropdownButton = new Gtk.Button({ label: "Select an icon" });
      dropdownButton.connect("button-press-event", () => {
        if (dropdownMenu.visible) {
          dropdownMenu.hide();
        } else {
          dropdownMenu.show();
          let [x, y] = dropdownButton.get_window().get_origin();
          dropdownMenu.set_position(
            x,
            y + dropdownButton.get_allocated_height()
          );
          dropdownMenu.set_size_request(
            iconGrid.get_allocated_width(),
            iconGrid.get_allocated_height()
          );
        }
      });

      //

      let hBoxIcon = new Gtk.Box();
      hBoxIcon.set_orientation(Gtk.Orientation.HORIZONTAL);
      hBoxIcon.append(iconLabel);
      hBoxIcon.append(iconPreview);
      hBoxIcon.append(dropdownButton);
      hBoxIcon.append(dropdownMenu);

      let addButton = new Gtk.Button({
        label: "Add Button",
      });
      addButton.connect("clicked", () => {
        this.addNewButton();
      });

      let vBox = new Gtk.Box();
      vBox.set_orientation(Gtk.Orientation.VERTICAL);
      vBox.append(hBoxIcon);
      vBox.append(addButton);
      this.add(vBox);
    }
  }

  updatePreviewCb(iconPath) {
    let pixbuf = GdkPixbuf.Pixbuf.new_from_file(iconPath);
    this.iconPreview.set_from_pixbuf(pixbuf);

    return true;
  }

  addNewButton() {}
}
